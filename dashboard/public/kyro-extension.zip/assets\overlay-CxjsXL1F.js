var e=null,t=null,n=-1;function r(){if(t)return t;t=document.createElement(`div`),t.id=`kyro-memory-overlay`,t.style.cssText=`
    position: fixed;
    width: 100%;
    max-height: 250px;
    overflow-y: auto;
    background: #1e1e2e;
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 12px;
    margin-bottom: 8px;
    z-index: 10000;
    display: none;
    flex-direction: column;
    box-shadow: 0 -10px 40px rgba(0,0,0,0.5);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    opacity: 0;
    transition: opacity 0.3s ease;
  `;let e=document.createElement(`div`);return e.id=`kyro-memory-list`,e.style.cssText=`
    padding: 8px;
    display: flex;
    flex-direction: column;
    gap: 4px;
  `,t.appendChild(e),t}function i(e,t){let i=r(),o=i.querySelector(`#kyro-memory-list`);if(o.innerHTML=``,n=-1,e.length===0){i.style.opacity=`0`,setTimeout(()=>i.style.display=`none`,300);return}e.forEach((e,r)=>{let i=``,s=``;typeof e==`string`?(i=e,s=e):e&&typeof e==`object`&&(i=e.text||JSON.stringify(e),s=e.id||i);let c=document.createElement(`div`);c.className=`kyro-memory-item`,c.dataset.index=r.toString(),c.style.cssText=`
      padding: 10px;
      background: rgba(255,255,255,0.03);
      border: 1px solid rgba(255,255,255,0.05);
      border-radius: 8px;
      color: #e2e8f0;
      font-size: 13px;
      line-height: 1.4;
      cursor: pointer;
      transition: all 0.2s;
    `;let l=document.createElement(`div`);l.style.cssText=`
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 8px;
    `;let u=document.createElement(`div`);u.style.flex=`1`,u.innerText=i;let d=document.createElement(`div`);d.style.cssText=`
      display: flex;
      gap: 4px;
      flex-direction: column;
    `;let f=document.createElement(`button`);f.innerText=`👍`,f.style.cssText=`background: none; border: none; cursor: pointer; filter: grayscale(100%); transition: all 0.2s; font-size: 14px;`;let p=document.createElement(`button`);p.innerText=`👎`,p.style.cssText=`background: none; border: none; cursor: pointer; filter: grayscale(100%); transition: all 0.2s; font-size: 14px;`;let m=(e,t)=>{chrome.runtime.sendMessage({type:`SEND_FEEDBACK`,memory_id:s,rating:e}),t.style.filter=`grayscale(0%)`,t.style.transform=`scale(1.2)`,setTimeout(()=>t.style.transform=`scale(1)`,200)};f.addEventListener(`click`,e=>{e.stopPropagation(),m(1,f),p.style.filter=`grayscale(100%)`}),p.addEventListener(`click`,e=>{e.stopPropagation(),m(-1,p),f.style.filter=`grayscale(100%)`}),d.appendChild(f),d.appendChild(p),l.appendChild(u),l.appendChild(d),c.appendChild(l),c.addEventListener(`mouseenter`,()=>{n!==r&&(c.style.background=`rgba(168,85,247,0.1)`,c.style.borderColor=`rgba(168,85,247,0.3)`)}),c.addEventListener(`mouseleave`,()=>{n!==r&&(c.style.background=`rgba(255,255,255,0.03)`,c.style.borderColor=`rgba(255,255,255,0.05)`)}),c.addEventListener(`click`,()=>{a(i,t)}),o.appendChild(c)}),document.body.contains(i)||document.body.appendChild(i);let s=t.getBoundingClientRect();i.style.bottom=`${window.innerHeight-s.top+10}px`,i.style.left=`${s.left}px`,i.style.width=`${s.width}px`,i.style.display=`flex`,requestAnimationFrame(()=>{i.style.opacity=`1`})}function a(e,n){n instanceof HTMLTextAreaElement?(n.value=e,n.dispatchEvent(new Event(`input`,{bubbles:!0}))):(n.innerText=e,n.dispatchEvent(new Event(`input`,{bubbles:!0}))),t&&(t.style.opacity=`0`,setTimeout(()=>t.style.display=`none`,300))}function o(r){document.addEventListener(`input`,n=>{let a=n.target,o=r();if(o&&(a===o||o.contains(a))){let n=``;n=o instanceof HTMLTextAreaElement?o.value:o.innerText,e&&clearTimeout(e),n.trim().length>10?e=window.setTimeout(()=>{chrome.runtime.sendMessage({type:`RETRIEVE_CONTEXT`,query:n},e=>{let t=``;t=o instanceof HTMLTextAreaElement?o.value:o.innerText,t.trim().length>10&&e&&e.status===`success`&&e.memories&&i(e.memories,o)})},1200):t&&(t.style.opacity=`0`,setTimeout(()=>{t&&(t.style.display=`none`)},300))}},!0),document.addEventListener(`keydown`,e=>{if(!t||t.style.display===`none`)return;let i=r(),o=document.activeElement;if(!i||o!==i&&!i.contains(o))return;let c=Array.from(t.querySelectorAll(`.kyro-memory-item`));if(c.length!==0)if(e.key===`ArrowDown`)e.preventDefault(),n=(n+1)%c.length,s(c);else if(e.key===`ArrowUp`)e.preventDefault(),n=(n-1+c.length)%c.length,s(c);else if(e.key===`Tab`){if(e.preventDefault(),n>=0&&n<c.length){let e=c[n].querySelector(`div > div`);e&&a(e.innerText,i)}else if(c.length>0){let e=c[0].querySelector(`div > div`);e&&a(e.innerText,i)}}else e.key===`Escape`&&(t.style.opacity=`0`,setTimeout(()=>{t&&(t.style.display=`none`)},300))},!0)}function s(e){e.forEach((e,t)=>{t===n?(e.style.background=`rgba(168,85,247,0.2)`,e.style.borderColor=`rgba(168,85,247,0.5)`,e.scrollIntoView({block:`nearest`})):(e.style.background=`rgba(255,255,255,0.03)`,e.style.borderColor=`rgba(255,255,255,0.05)`)})}export{o as t};