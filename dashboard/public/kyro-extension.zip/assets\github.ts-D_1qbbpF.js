(function(){function e(){let e=[],t=document.querySelector(`.js-issue-title`);t&&e.push(`Title: ${t.textContent?.trim()}`);let n=document.querySelector(`.comment-body`);n&&e.push(`Description: ${n.textContent?.trim()}`);let r=document.querySelectorAll(`table.diff-table`);return r.length>0&&(e.push(`Code Changes:`),Array.from(r).slice(0,5).forEach(t=>{let n=(t.parentElement?.previousElementSibling)?.textContent?.trim().replace(/\s+/g,` `)||`Unknown File`;e.push(`File: ${n}`);let r=t.querySelectorAll(`.blob-code-addition`),i=t.querySelectorAll(`.blob-code-deletion`);if(r.length>0){let t=Array.from(r).map(e=>e.textContent?.trim().replace(/^\+/,``)).join(`
`);t.length>500&&(t=t.substring(0,500)+`... (truncated)`),e.push(`Additions:\n${t}`)}if(i.length>0){let t=Array.from(i).map(e=>e.textContent?.trim().replace(/^-/,``)).join(`
`);t.length>500&&(t=t.substring(0,500)+`... (truncated)`),e.push(`Deletions:\n${t}`)}})),e.join(`

`)}function t(){let t=window.location.href,n=document.title,r=e();if(r.length<50){console.log(`[Kyro GitHub] Not enough semantic content found, skipping capture.`);return}let i=r.length>3e3?r.substring(0,3e3)+`
... (truncated for memory limits)`:r,a={url:t,title:n,text:`[GitHub Source] ${i}`,domain:window.location.hostname,timestamp:new Date().toISOString(),type:`github_context`};chrome.runtime.sendMessage({type:`CAPTURE_CONTEXT`,data:a}),console.log(`[Kyro] Successfully captured specialized GitHub context (${i.length} chars)`)}setTimeout(()=>{t();let e=document.querySelector(`.js-issue-title`);if(e&&e.textContent){let t=e.textContent.trim();chrome.runtime.sendMessage({type:`RETRIEVE_CONTEXT`,query:t},e=>{e&&e.status===`success`&&e.memories&&e.memories.length>0&&n(t,e.memories.length)})}},2e3);function n(e,t){if(document.getElementById(`kyro-collision-alert`))return;let n=document.createElement(`div`);n.id=`kyro-collision-alert`,n.style.cssText=`
    position: fixed;
    bottom: 24px;
    left: 24px;
    background: #09090b;
    border: 1px solid rgba(168, 85, 247, 0.4);
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5), 0 0 20px rgba(168, 85, 247, 0.2);
    border-radius: 12px;
    padding: 16px;
    z-index: 999999;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
    color: white;
    display: flex;
    flex-direction: column;
    gap: 8px;
    width: 300px;
    animation: kyroSlideIn 0.5s cubic-bezier(0.16, 1, 0.3, 1) forwards;
  `,n.innerHTML=`
    <style>
      @keyframes kyroSlideIn {
        from { transform: translateY(100px) scale(0.9); opacity: 0; }
        to { transform: translateY(0) scale(1); opacity: 1; }
      }
      .kyro-dismiss:hover { background: rgba(255,255,255,0.1); }
    </style>
    <div style="display: flex; justify-content: space-between; align-items: center;">
      <div style="display: flex; align-items: center; gap: 8px; color: #a855f7; font-weight: 600; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px;">
        <span>✨ Kyro Collision</span>
      </div>
      <button class="kyro-dismiss" style="background: transparent; border: none; color: #71717a; cursor: pointer; padding: 4px; border-radius: 4px; display: flex; align-items: center; justify-content: center;">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
      </button>
    </div>
    <div style="font-size: 14px; color: #e4e4e7; line-height: 1.5;">
      Found <strong>${t}</strong> related memories for <span style="color: #60a5fa;">"${e}"</span> in your Kyro Graph.
    </div>
  `,document.body.appendChild(n),n.querySelector(`.kyro-dismiss`)?.addEventListener(`click`,()=>{n.style.animation=`none`,n.style.opacity=`0`,n.style.transform=`translateY(20px)`,n.style.transition=`all 0.3s ease`,setTimeout(()=>n.remove(),300)})}document.addEventListener(`keydown`,e=>{chrome.storage.local.get([`kyro_capture_keybind`],t=>{let n=(t.kyro_capture_keybind||`Alt+C`).split(`+`).map(e=>e.trim().toLowerCase()),r=n.includes(`alt`),i=n.includes(`ctrl`),a=n.includes(`shift`),o=n.includes(`meta`),s=n.find(e=>![`alt`,`ctrl`,`shift`,`meta`].includes(e));if(e.altKey===r&&e.ctrlKey===i&&e.shiftKey===a&&e.metaKey===o&&s&&e.key.toLowerCase()===s){let e=window.getSelection()?.toString();if(e&&e.length>0){chrome.runtime.sendMessage({type:`CAPTURE_CONTEXT`,data:{text:e,url:window.location.href,title:`Selection from: ${document.title}`,timestamp:new Date().toISOString(),type:`selection`,domain:window.location.hostname}});let t=document.createElement(`div`);t.innerText=`✨ Captured to Kyro!`,t.style.cssText=`position:fixed;bottom:24px;right:24px;background:#a855f7;color:white;padding:8px 16px;border-radius:8px;z-index:999999;font-family:sans-serif;font-size:14px;font-weight:600;box-shadow:0 4px 12px rgba(0,0,0,0.3);transition: opacity 0.3s;`,document.body.appendChild(t),setTimeout(()=>{t.style.opacity=`0`,setTimeout(()=>t.remove(),300)},1500)}}})});})()