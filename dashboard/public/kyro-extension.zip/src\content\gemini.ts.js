// Kyro: Lightweight Gemini Interceptor
function getPromptTextArea() {
	return document.querySelector(".text-input-field") || document.querySelector(".gmat-mdc-text-field") || document.querySelector("rich-textarea") || document.querySelector("div[contenteditable=\"true\"]");
}
function getSendButton() {
	return document.querySelector("button[aria-label=\"Send message\"]") || document.querySelector(".send-button");
}
function sendToKyro(text) {
	if (!text || text.trim().length < 5) return;
	chrome.runtime.sendMessage({
		type: "CAPTURE_CONTEXT",
		data: {
			url: window.location.href,
			title: `Gemini Prompt`,
			text: `User Prompt: ${text.trim()}`,
			domain: "gemini.google.com",
			timestamp: new Date().toISOString(),
			type: "chat_prompt"
		}
	});
	console.log("[Kyro] Intercepted Gemini prompt.");
}
function interceptGemini() {
	document.addEventListener("keydown", (e) => {
		if (e.key === "Enter" && !e.shiftKey) {
			const activeEl = document.activeElement;
			const textArea = getPromptTextArea();
			if (activeEl === textArea || textArea?.contains(activeEl)) {
				let text = "";
				if (textArea instanceof HTMLTextAreaElement) text = textArea.value;
				else if (textArea) text = textArea.innerText;
				sendToKyro(text);
			}
		}
	}, true);
	document.addEventListener("click", (e) => {
		const sendBtn = getSendButton();
		const target = e.target;
		if (sendBtn && (target === sendBtn || sendBtn.contains(target))) {
			const textArea = getPromptTextArea();
			let text = "";
			if (textArea instanceof HTMLTextAreaElement) text = textArea.value;
			else if (textArea) text = textArea.innerText;
			sendToKyro(text);
		}
	}, true);
}
interceptGemini();
import { setupOverlay } from "/src/content/overlay.ts.js";
setupOverlay(getPromptTextArea);
