(function(){var e=null,t=null,n=!1;function r(){let e=document.createElement(`div`);e.id=`kyro-spotlight-root`,e.style.cssText=`
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.72);
    backdrop-filter: blur(6px);
    -webkit-backdrop-filter: blur(6px);
    z-index: 2147483646;
    display: flex;
    align-items: flex-start;
    justify-content: center;
    padding-top: 14vh;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    opacity: 0;
    transition: opacity 0.2s ease;
  `;let n=document.createElement(`div`);n.style.cssText=`
    width: 640px;
    max-width: calc(100vw - 32px);
    background: #0d0d14;
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 18px;
    box-shadow: 0 40px 80px rgba(0,0,0,0.9), 0 0 0 1px rgba(139,92,246,0.15);
    overflow: hidden;
    transform: translateY(-8px) scale(0.98);
    transition: transform 0.2s ease;
  `;let r=document.createElement(`div`);r.style.cssText=`
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 16px 20px;
    border-bottom: 1px solid rgba(255,255,255,0.07);
  `;let a=document.createElement(`span`);a.style.cssText=`font-size: 18px; flex-shrink: 0;`,a.textContent=`🔮`;let s=document.createElement(`input`);s.id=`kyro-spotlight-input`,s.placeholder=`Ask Kyro anything about your memory…`,s.autocomplete=`off`,s.spellcheck=!1,s.style.cssText=`
    flex: 1;
    background: none;
    border: none;
    outline: none;
    color: #f1f5f9;
    font-size: 16px;
    line-height: 1;
    caret-color: #a78bfa;
    min-width: 0;
  `;let c=document.createElement(`kbd`);c.textContent=`Esc`,c.style.cssText=`
    background: rgba(255,255,255,0.07);
    color: #6b7280;
    border: 1px solid rgba(255,255,255,0.1);
    padding: 2px 8px;
    border-radius: 6px;
    font-size: 11px;
    font-family: inherit;
    flex-shrink: 0;
  `,r.appendChild(a),r.appendChild(s),r.appendChild(c);let l=document.createElement(`div`);l.id=`kyro-spotlight-results`,l.style.cssText=`
    min-height: 72px;
    max-height: 320px;
    overflow-y: auto;
    padding: 8px;
  `,l.innerHTML=`<p style="color:#4b5563; font-size:13px; padding:16px 12px; text-align:center; margin:0;">Start typing to search your memory graph…</p>`;let u=document.createElement(`div`);return u.style.cssText=`
    padding: 8px 20px;
    border-top: 1px solid rgba(255,255,255,0.06);
    display: flex;
    align-items: center;
    gap: 16px;
  `,u.innerHTML=`
    <span style="font-size:11px; color:#374151;">
      <kbd style="background:rgba(255,255,255,0.07);padding:1px 6px;border-radius:4px;color:#9ca3af;font-family:inherit;">Esc</kbd>
      close
    </span>
    <span style="margin-left:auto; font-size:11px; color:#4b5563;">Powered by <span style="color:#a78bfa;">Kyro Brain</span></span>
  `,n.appendChild(r),n.appendChild(l),n.appendChild(u),e.appendChild(n),e.addEventListener(`click`,t=>{t.target===e&&o()}),s.addEventListener(`input`,()=>{t!==null&&clearTimeout(t);let e=s.value.trim();if(e.length<2){l.innerHTML=`<p style="color:#4b5563; font-size:13px; padding:16px 12px; text-align:center; margin:0;">Start typing to search your memory graph…</p>`;return}l.innerHTML=`<p style="color:#6b7280; font-size:13px; padding:16px 12px; text-align:center; margin:0;">Searching…</p>`,t=window.setTimeout(()=>i(e,l),450)}),e}function i(e,t){chrome.runtime.sendMessage({type:`RETRIEVE_CONTEXT`,query:e},n=>{let r=n?.memories||[];if(!r.length){t.innerHTML=`<p style="color:#6b7280; font-size:13px; padding:20px 12px; text-align:center; margin:0;">No memories found for "<strong style="color:#9ca3af;">${e}</strong>"</p>`;return}t.innerHTML=``,r.forEach(e=>{let n=typeof e==`string`?e:e.text||JSON.stringify(e),r=n.length>220?n.slice(0,220)+`…`:n,i=document.createElement(`div`);i.style.cssText=`
        padding: 12px 16px;
        border-radius: 10px;
        margin: 3px 0;
        cursor: default;
        border: 1px solid transparent;
        transition: background 0.12s, border-color 0.12s;
        display: flex;
        align-items: flex-start;
        gap: 12px;
      `;let a=document.createElement(`span`);a.style.cssText=`width: 6px; height: 6px; border-radius: 50%; background: #7c3aed; flex-shrink: 0; margin-top: 6px;`;let o=document.createElement(`span`);o.style.cssText=`color: #d1d5db; font-size: 13px; line-height: 1.55;`,o.textContent=r,i.appendChild(a),i.appendChild(o),i.addEventListener(`mouseenter`,()=>{i.style.background=`rgba(139,92,246,0.08)`,i.style.borderColor=`rgba(139,92,246,0.25)`}),i.addEventListener(`mouseleave`,()=>{i.style.background=``,i.style.borderColor=`transparent`}),t.appendChild(i)})})}function a(){(!e||!document.body.contains(e))&&(e=r(),document.body.appendChild(e)),e.style.display=`flex`,requestAnimationFrame(()=>{if(!e)return;e.style.opacity=`1`;let t=e.querySelector(`div`);t&&(t.style.transform=`translateY(0) scale(1)`)});let t=e.querySelector(`#kyro-spotlight-input`);t&&(t.value=``,setTimeout(()=>t.focus(),80));let i=e.querySelector(`#kyro-spotlight-results`);i&&(i.innerHTML=`<p style="color:#4b5563; font-size:13px; padding:16px 12px; text-align:center; margin:0;">Start typing to search your memory graph…</p>`),n=!0}function o(){if(!e)return;e.style.opacity=`0`;let t=e.querySelector(`div`);t&&(t.style.transform=`translateY(-8px) scale(0.98)`),setTimeout(()=>{e&&(e.style.display=`none`)},200),n=!1}function s(){n?o():a()}document.addEventListener(`keydown`,e=>{e.key===`Escape`&&n&&(e.preventDefault(),o())},!0),chrome.runtime.onMessage.addListener(e=>{e.type===`TOGGLE_SPOTLIGHT`&&s()});function c(){let e=[`article`,`main`,`.markdown-body`,`.post-content`,`#content`,`[role="main"]`],t=null;for(let n of e)if(t=document.querySelector(n),t)break;return t?t.innerText.trim():Array.from(document.querySelectorAll(`p`)).map(e=>e.innerText.trim()).filter(e=>e.length>50).join(`\\n\\n`)}function l(){let e=window.location.href,t=document.title,n=c();if(n.length<100){console.log(`[Kyro] Page content too short, skipping capture.`);return}let r={url:e,title:t,text:n,domain:window.location.hostname,timestamp:new Date().toISOString(),type:`page_view`};chrome.runtime.sendMessage({type:`CAPTURE_CONTEXT`,data:r})}var u=0,d=!1,f=Date.now(),p=15e3;function m(e,t,n){let r=t.some(t=>e.includes(t));return n===`allow`?r:!r}function h(){d||(Date.now()-f<5e3&&(u+=1e3),u>=p?chrome.storage.local.get([`kyro_blocklist`,`kyro_blocklist_mode`],e=>{let t=e.kyro_blocklist||[],n=e.kyro_blocklist_mode||`block`;m(window.location.hostname,t,n)?(console.log(`[Kyro] User engagement threshold reached. Capturing article.`),d=!0,l()):(console.log(`[Kyro] Capture suppressed by Privacy Controls for: ${window.location.hostname}`),d=!0)}):setTimeout(h,1e3))}var g=()=>{f=Date.now()};document.addEventListener(`scroll`,g,{passive:!0}),document.addEventListener(`mousemove`,g,{passive:!0}),document.addEventListener(`keydown`,g,{passive:!0}),setTimeout(h,1e3),document.addEventListener(`keydown`,e=>{chrome.storage.local.get([`kyro_capture_keybind`,`kyro_blocklist`,`kyro_blocklist_mode`],t=>{let n=t.kyro_capture_keybind||`Alt+C`,r=t.kyro_blocklist||[],i=t.kyro_blocklist_mode||`block`,a=n.split(`+`).map(e=>e.trim().toLowerCase()),o=a.includes(`alt`),s=a.includes(`ctrl`),c=a.includes(`shift`),l=a.includes(`meta`),u=a.find(e=>![`alt`,`ctrl`,`shift`,`meta`].includes(e));if(e.altKey===o&&e.ctrlKey===s&&e.shiftKey===c&&e.metaKey===l&&u&&e.key.toLowerCase()===u){if(!m(window.location.hostname,r,i)){console.log(`[Kyro] Keybind capture suppressed by Privacy Controls for: ${window.location.hostname}`);return}let e=window.getSelection()?.toString();if(e&&e.length>0){chrome.runtime.sendMessage({type:`CAPTURE_CONTEXT`,data:{text:e,url:window.location.href,title:`Selection from: ${document.title}`,timestamp:new Date().toISOString(),type:`selection`,domain:window.location.hostname}});let t=document.createElement(`div`);t.innerText=`✨ Captured to Kyro!`,t.style.cssText=`position:fixed;bottom:24px;right:24px;background:#a855f7;color:white;padding:8px 16px;border-radius:8px;z-index:999999;font-family:sans-serif;font-size:14px;font-weight:600;box-shadow:0 4px 12px rgba(0,0,0,0.3);transition: opacity 0.3s;`,document.body.appendChild(t),setTimeout(()=>{t.style.opacity=`0`,setTimeout(()=>t.remove(),300)},1500)}}})});})()